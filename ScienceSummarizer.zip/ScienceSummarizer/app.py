# ✅ Science Summarizer app.py - النسخة المطورة

from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response
import sqlite3
import os
import fitz  # PyMuPDF
import spacy
from transformers import pipeline
from werkzeug.utils import secure_filename
import re

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# ✅ تحميل الموديلات
summarizer = pipeline("summarization", model="t5-large")
nlp = spacy.load("en_core_sci_lg")

# ✅ الاتصال بقاعدة البيانات

def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS User (
            User_id INTEGER PRIMARY KEY AUTOINCREMENT,
            User_name TEXT NOT NULL,
            Email TEXT NOT NULL UNIQUE,
            Password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# ✅ دوال مساعدة

def clean_text(text):
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'Page \d+', '', text)
    text = re.sub(r'www\.[^\s]+', '', text)
    return text


def split_text(text, chunk_size=500):
    words = text.split()
    return [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]


def summarize_text(text, max_length=150):
    chunks = split_text(text)
    summaries = [summarizer(chunk, max_length=max_length, min_length=50, do_sample=False)[0]['summary_text'] for chunk in chunks]
    return " ".join(summaries)


def extract_pico(text):
    doc = nlp(text)
    sentences = [sent.text.strip() for sent in doc.sents if len(sent.text.strip()) > 40]

    pico = {"Participants": [], "Intervention": [], "Comparison": [], "Outcome": []}
    for sentence in sentences:
        sent_lower = sentence.lower()
        if any(w in sent_lower for w in ["participants", "patients", "subjects"]):
            pico["Participants"].append(sentence)
        elif any(w in sent_lower for w in ["intervention", "treatment", "therapy", "method"]):
            pico["Intervention"].append(sentence)
        elif any(w in sent_lower for w in ["comparison", "control", "versus", "placebo"]):
            pico["Comparison"].append(sentence)
        elif any(w in sent_lower for w in ["outcome", "result", "effectiveness", "impact"]):
            pico["Outcome"].append(sentence)

    return pico

# ✅ المسارات

@app.route('/')
def home_page():
    return render_template('Home1.html')

@app.route('/aboutus')
def aboutus_page():
    return render_template('Aboutus.html')

@app.route('/login')
def login_page():
    return render_template('LoginOne.html')

@app.route('/signin')
def signin_page():
    return render_template('SigninOne.html')

@app.route('/signup', methods=['POST'])
def signup():
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO User (User_name, Email, Password) VALUES (?, ?, ?)", (username, email, password))
        conn.commit()
        flash("Account created successfully. Please login.", "success")
    except sqlite3.IntegrityError:
        flash("Username or Email already exists.", "danger")
    conn.close()
    return redirect(url_for('login_page'))

@app.route('/login', methods=['POST'])
def login():
    user_id = request.form['user_id']
    password = request.form['password']

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM User WHERE User_name=? AND Password=?", (user_id, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        session['user_id'] = user_id
        return redirect(url_for('upload_page'))
    else:
        flash("Invalid credentials.", "danger")
        return redirect(url_for('login_page'))

@app.route('/upload')
def upload_page():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))
    username = session.get('user_id')
    return render_template('UploadpageOne.html', username=username)

@app.route('/process', methods=['POST'])
def process_upload():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))

    text_input = request.form.get('text_box')
    file = request.files.get('file')

    if text_input and text_input.strip():
        pdf_text = text_input.strip()
        session['filename'] = 'Text Input'
    elif file:
        filename = secure_filename(file.filename)
        file_ext = os.path.splitext(filename)[1].lower()

        if file_ext not in ['.pdf', '.docx']:
            flash("The file should be PDF or DOCX extension!", "danger")
            return redirect(url_for('upload_page'))

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        session['filename'] = filename

        if file_ext == '.pdf':
            doc = fitz.open(filepath)
            pdf_text = "\n".join([page.get_text("text") for page in doc])
        else:
            pdf_text = "DOCX processing not implemented yet."
    else:
        flash("Please upload a file or enter some text!", "danger")
        return redirect(url_for('upload_page'))

    pdf_text = clean_text(pdf_text)
    summary = summarize_text(pdf_text)
    pico = extract_pico(pdf_text)

    session['summary'] = summary
    session['pico'] = pico

    return redirect(url_for('results_page'))

@app.route('/results')
def results_page():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))
    summary = session.get('summary', '')
    pico = session.get('pico', {})
    return render_template('Resultspage1p.html', summary=summary, pico=pico)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

if __name__ == '__main__':
    app.run(debug=True)
